#include <common.h>

void mxs_set_divcpu(uint8_t clkdiv);